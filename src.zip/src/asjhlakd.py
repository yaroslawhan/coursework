import os
import sys
print(os.path.dirname(sys.executable))
